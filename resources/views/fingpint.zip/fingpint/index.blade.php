<!-- app/views/layouts/master.blade.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Simple CMS" />
    <meta name="author" content="Sheikh Heera" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js" integrity="sha384-LtrjvnR4Twt/qOuYxE721u19sVFLVSA4hf/rRt6PrZTmiPltdZcI7q7PXQBYTKyf" crossorigin="anonymous"></script>
</head>

<body>
    <form enctype="multipart/form-data" class="container" method="post" action="{{url('/create')}}" accept-charset="UTF-8">
        @csrf
        <input hidden value="" name="id" type="text" class="form-control" id="exampleFormControlInput1">
        <div class="card" style=" text-align: center"><br>
            <h5 class="card-header">Information</h5>
        </div>
        <div class="card-body">
            <h5 class="card-title">
                <div class="form-group">
                    <label for="exampleFormControlInput1">Name</label>
                    <input value="" name="name" type="text" class="form-control" id="exampleFormControlInput1">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Age</label>
                    <input value="" name="age" type="text" class="form-control" id="exampleFormControlInput1">
                </div>


                <div class="form-group">
                    <label for="exampleFormControlSelect2">Interest</label>
                    <select name="interest" class="form-control" id="exampleFormControlSelect2">
                        <option value="ฟุตบอล"> ฟุตบอล</option>
                        <option value="เพลง">เพลง</option>
                        <option value="ดูหนัง">ดูหนัง</option>


                    </select>
                </div>

                <div class="form-group">
                    <label for="exampleFormControlInput1">รูป</label>
                    <input value="" name="imguser" type="file" class="form-control" id="exampleFormControlInput1">
                </div>

                <div class="form-group">
                    <label for="exampleFormControlInput1">รูปนิ้วมือ</label>
                    <input value="" name="fingerprint" type="file" class="form-control form-control-file" id="exampleFormControlInput1">
                </div>

                <div class="form-group">
                    <!-- <label for="exampleFormControlTextarea1">Example textarea</label> -->
                    <!-- <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea> -->
                    <br>
                </div>
                <center><input type="submit" value="Submit" style="width:200px;height:50px" class="btn btn-primary"></center>
                
    </form><br><br>

    <center>
        <div class="card">
            <h5 class="card-header">Information</h5>
        </div>
    </center>

    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Age</th>
                    <th scope="col">Interest</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>

                </tr>
            </thead>
            <tbody>
                @foreach($data as $row)
                <tr>
                    <th scope="row">
                        {{$row->name}}
                    </th>
                    <td>
                        {{$row->age}}
                    </td>
                    <td>
                        {{$row-> interest}}
                    </td>
                    <td>
                        <a href="{{url('/edit/'.$row->id)}}">
                            <button type="button" class="btn btn-secondary">เเก้ไขข้อมูล</button>
                        </a>

                    <td>
                        <a href="{{url('/delete/'.$row->id)}}">
                            <button type="button" style="width:150px;height:40px" class="btn btn-danger">ลบ</button>
                        </a>
                    </td>


                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

</body>

</html>